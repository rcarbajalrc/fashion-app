// Servicio para gestionar los datos de usuario
import { db } from './firebase';
import { 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc, 
  serverTimestamp 
} from 'firebase/firestore';

// Guardar datos de usuario
export const saveUserData = async (userId, userData) => {
  try {
    await setDoc(doc(db, "users", userId), {
      ...userData,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
    return { success: true };
  } catch (error) {
    console.error("Error al guardar datos de usuario:", error);
    return { success: false, error: error.message };
  }
};

// Obtener datos de usuario
export const getUserData = async (userId) => {
  try {
    const docRef = doc(db, "users", userId);
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
      return { success: true, userData: docSnap.data() };
    } else {
      return { success: false, error: "No se encontraron datos de usuario" };
    }
  } catch (error) {
    console.error("Error al obtener datos de usuario:", error);
    return { success: false, error: error.message };
  }
};

// Actualizar datos de usuario
export const updateUserData = async (userId, userData) => {
  try {
    const userRef = doc(db, "users", userId);
    await updateDoc(userRef, {
      ...userData,
      updatedAt: serverTimestamp()
    });
    return { success: true };
  } catch (error) {
    console.error("Error al actualizar datos de usuario:", error);
    return { success: false, error: error.message };
  }
};
