// Servicio para gestionar el feed de inspiración
import { db } from './firebase';
import { 
  collection, 
  doc, 
  addDoc, 
  getDoc, 
  getDocs, 
  query, 
  where, 
  limit,
  orderBy,
  serverTimestamp 
} from 'firebase/firestore';

// Función para obtener posts del feed de inspiración
export const getInspirationFeed = async (limitCount = 10) => {
  try {
    const feedRef = collection(db, "inspirationFeed");
    const q = query(
      feedRef,
      orderBy("createdAt", "desc"),
      limit(limitCount)
    );
    const querySnapshot = await getDocs(q);
    
    const posts = [];
    querySnapshot.forEach((doc) => {
      posts.push({ id: doc.id, ...doc.data() });
    });
    
    return { success: true, posts };
  } catch (error) {
    console.error("Error al obtener feed de inspiración:", error);
    return { success: false, error: error.message };
  }
};

// Función para obtener posts por categoría
export const getInspirationByCategory = async (category, limitCount = 10) => {
  try {
    const feedRef = collection(db, "inspirationFeed");
    const q = query(
      feedRef,
      where("categories", "array-contains", category),
      orderBy("createdAt", "desc"),
      limit(limitCount)
    );
    const querySnapshot = await getDocs(q);
    
    const posts = [];
    querySnapshot.forEach((doc) => {
      posts.push({ id: doc.id, ...doc.data() });
    });
    
    return { success: true, posts };
  } catch (error) {
    console.error("Error al obtener inspiración por categoría:", error);
    return { success: false, error: error.message };
  }
};

// Función para obtener un post específico
export const getInspirationPost = async (postId) => {
  try {
    const docRef = doc(db, "inspirationFeed", postId);
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
      return { success: true, post: { id: docSnap.id, ...docSnap.data() } };
    } else {
      return { success: false, error: "No se encontró el post" };
    }
  } catch (error) {
    console.error("Error al obtener post:", error);
    return { success: false, error: error.message };
  }
};

// Función para dar like a un post
export const likeInspirationPost = async (userId, postId) => {
  try {
    const likesRef = collection(db, "inspirationLikes");
    
    // Verificar si ya dio like
    const q = query(
      likesRef,
      where("userId", "==", userId),
      where("postId", "==", postId)
    );
    const querySnapshot = await getDocs(q);
    
    if (querySnapshot.empty) {
      // Añadir like
      await addDoc(likesRef, {
        userId,
        postId,
        createdAt: serverTimestamp()
      });
      
      return { success: true, action: "liked" };
    } else {
      // Ya dio like, no hacer nada
      return { success: true, action: "already_liked" };
    }
  } catch (error) {
    console.error("Error al dar like:", error);
    return { success: false, error: error.message };
  }
};

// Función para guardar un post en favoritos
export const saveInspirationPost = async (userId, postId) => {
  try {
    const savedRef = collection(db, "inspirationSaved");
    
    // Verificar si ya está guardado
    const q = query(
      savedRef,
      where("userId", "==", userId),
      where("postId", "==", postId)
    );
    const querySnapshot = await getDocs(q);
    
    if (querySnapshot.empty) {
      // Guardar post
      await addDoc(savedRef, {
        userId,
        postId,
        createdAt: serverTimestamp()
      });
      
      return { success: true, action: "saved" };
    } else {
      // Ya está guardado, no hacer nada
      return { success: true, action: "already_saved" };
    }
  } catch (error) {
    console.error("Error al guardar post:", error);
    return { success: false, error: error.message };
  }
};

// Función para obtener posts guardados por el usuario
export const getSavedInspirationPosts = async (userId) => {
  try {
    const savedRef = collection(db, "inspirationSaved");
    const q = query(
      savedRef,
      where("userId", "==", userId),
      orderBy("createdAt", "desc")
    );
    const querySnapshot = await getDocs(q);
    
    const savedPostIds = [];
    querySnapshot.forEach((doc) => {
      savedPostIds.push(doc.data().postId);
    });
    
    // Obtener detalles de los posts guardados
    const posts = [];
    for (const postId of savedPostIds) {
      const postResult = await getInspirationPost(postId);
      if (postResult.success) {
        posts.push(postResult.post);
      }
    }
    
    return { success: true, posts };
  } catch (error) {
    console.error("Error al obtener posts guardados:", error);
    return { success: false, error: error.message };
  }
};
