// Servicio para gestionar los outfits
import { db } from './firebase';
import { 
  collection, 
  doc, 
  addDoc, 
  getDoc, 
  getDocs, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  orderBy,
  serverTimestamp 
} from 'firebase/firestore';

// Crear un nuevo outfit
export const createOutfit = async (userId, outfitData) => {
  try {
    const outfitsRef = collection(db, "outfits");
    const docRef = await addDoc(outfitsRef, {
      ...outfitData,
      userId,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
    
    return { success: true, id: docRef.id };
  } catch (error) {
    console.error("Error al crear outfit:", error);
    return { success: false, error: error.message };
  }
};

// Obtener todos los outfits del usuario
export const getUserOutfits = async (userId) => {
  try {
    const outfitsRef = collection(db, "outfits");
    const q = query(
      outfitsRef,
      where("userId", "==", userId),
      orderBy("createdAt", "desc")
    );
    const querySnapshot = await getDocs(q);
    
    const outfits = [];
    querySnapshot.forEach((doc) => {
      outfits.push({ id: doc.id, ...doc.data() });
    });
    
    return { success: true, outfits };
  } catch (error) {
    console.error("Error al obtener outfits:", error);
    return { success: false, error: error.message };
  }
};

// Obtener outfits por ocasión
export const getOutfitsByOccasion = async (userId, occasion) => {
  try {
    const outfitsRef = collection(db, "outfits");
    const q = query(
      outfitsRef,
      where("userId", "==", userId),
      where("occasion", "==", occasion),
      orderBy("createdAt", "desc")
    );
    const querySnapshot = await getDocs(q);
    
    const outfits = [];
    querySnapshot.forEach((doc) => {
      outfits.push({ id: doc.id, ...doc.data() });
    });
    
    return { success: true, outfits };
  } catch (error) {
    console.error("Error al obtener outfits por ocasión:", error);
    return { success: false, error: error.message };
  }
};

// Obtener outfits por temporada
export const getOutfitsBySeason = async (userId, season) => {
  try {
    const outfitsRef = collection(db, "outfits");
    const q = query(
      outfitsRef,
      where("userId", "==", userId),
      where("season", "==", season),
      orderBy("createdAt", "desc")
    );
    const querySnapshot = await getDocs(q);
    
    const outfits = [];
    querySnapshot.forEach((doc) => {
      outfits.push({ id: doc.id, ...doc.data() });
    });
    
    return { success: true, outfits };
  } catch (error) {
    console.error("Error al obtener outfits por temporada:", error);
    return { success: false, error: error.message };
  }
};

// Obtener un outfit específico
export const getOutfit = async (outfitId) => {
  try {
    const docRef = doc(db, "outfits", outfitId);
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
      return { success: true, outfit: { id: docSnap.id, ...docSnap.data() } };
    } else {
      return { success: false, error: "No se encontró el outfit" };
    }
  } catch (error) {
    console.error("Error al obtener outfit:", error);
    return { success: false, error: error.message };
  }
};

// Actualizar outfit
export const updateOutfit = async (outfitId, outfitData) => {
  try {
    const outfitRef = doc(db, "outfits", outfitId);
    await updateDoc(outfitRef, {
      ...outfitData,
      updatedAt: serverTimestamp()
    });
    
    return { success: true };
  } catch (error) {
    console.error("Error al actualizar outfit:", error);
    return { success: false, error: error.message };
  }
};

// Eliminar outfit
export const deleteOutfit = async (outfitId) => {
  try {
    await deleteDoc(doc(db, "outfits", outfitId));
    return { success: true };
  } catch (error) {
    console.error("Error al eliminar outfit:", error);
    return { success: false, error: error.message };
  }
};

// Planificar outfit para una fecha específica
export const planOutfit = async (userId, outfitId, date) => {
  try {
    const plannedRef = collection(db, "plannedOutfits");
    await addDoc(plannedRef, {
      userId,
      outfitId,
      date,
      createdAt: serverTimestamp()
    });
    
    return { success: true };
  } catch (error) {
    console.error("Error al planificar outfit:", error);
    return { success: false, error: error.message };
  }
};

// Obtener outfits planificados en un rango de fechas
export const getPlannedOutfits = async (userId, startDate, endDate) => {
  try {
    const plannedRef = collection(db, "plannedOutfits");
    const q = query(
      plannedRef,
      where("userId", "==", userId),
      where("date", ">=", startDate),
      where("date", "<=", endDate),
      orderBy("date", "asc")
    );
    const querySnapshot = await getDocs(q);
    
    const plannedOutfits = [];
    for (const doc of querySnapshot.docs) {
      const plannedData = doc.data();
      const outfitResult = await getOutfit(plannedData.outfitId);
      
      if (outfitResult.success) {
        plannedOutfits.push({
          id: doc.id,
          date: plannedData.date,
          outfit: outfitResult.outfit
        });
      }
    }
    
    return { success: true, plannedOutfits };
  } catch (error) {
    console.error("Error al obtener outfits planificados:", error);
    return { success: false, error: error.message };
  }
};
