// Servicio para gestionar el armario digital (prendas de ropa)
import { db, storage } from './firebase';
import { 
  collection, 
  doc, 
  addDoc, 
  getDoc, 
  getDocs, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  orderBy,
  serverTimestamp 
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';

// Subir imagen de prenda
export const uploadClothingImage = async (userId, file) => {
  try {
    const fileExtension = file.name.split('.').pop();
    const fileName = `${userId}_${Date.now()}.${fileExtension}`;
    const storageRef = ref(storage, `clothing/${userId}/${fileName}`);
    
    await uploadBytes(storageRef, file);
    const downloadURL = await getDownloadURL(storageRef);
    
    return { success: true, imageUrl: downloadURL };
  } catch (error) {
    console.error("Error al subir imagen:", error);
    return { success: false, error: error.message };
  }
};

// Añadir prenda al armario
export const addClothingItem = async (userId, itemData) => {
  try {
    const clothingRef = collection(db, "clothing");
    const docRef = await addDoc(clothingRef, {
      ...itemData,
      userId,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
    
    return { success: true, id: docRef.id };
  } catch (error) {
    console.error("Error al añadir prenda:", error);
    return { success: false, error: error.message };
  }
};

// Obtener todas las prendas del usuario
export const getUserClothingItems = async (userId) => {
  try {
    const clothingRef = collection(db, "clothing");
    const q = query(
      clothingRef,
      where("userId", "==", userId),
      orderBy("createdAt", "desc")
    );
    const querySnapshot = await getDocs(q);
    
    const items = [];
    querySnapshot.forEach((doc) => {
      items.push({ id: doc.id, ...doc.data() });
    });
    
    return { success: true, items };
  } catch (error) {
    console.error("Error al obtener prendas:", error);
    return { success: false, error: error.message };
  }
};

// Obtener prendas por categoría
export const getClothingItemsByCategory = async (userId, category) => {
  try {
    const clothingRef = collection(db, "clothing");
    const q = query(
      clothingRef,
      where("userId", "==", userId),
      where("category", "==", category),
      orderBy("createdAt", "desc")
    );
    const querySnapshot = await getDocs(q);
    
    const items = [];
    querySnapshot.forEach((doc) => {
      items.push({ id: doc.id, ...doc.data() });
    });
    
    return { success: true, items };
  } catch (error) {
    console.error("Error al obtener prendas por categoría:", error);
    return { success: false, error: error.message };
  }
};

// Obtener una prenda específica
export const getClothingItem = async (itemId) => {
  try {
    const docRef = doc(db, "clothing", itemId);
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
      return { success: true, item: { id: docSnap.id, ...docSnap.data() } };
    } else {
      return { success: false, error: "No se encontró la prenda" };
    }
  } catch (error) {
    console.error("Error al obtener prenda:", error);
    return { success: false, error: error.message };
  }
};

// Actualizar prenda
export const updateClothingItem = async (itemId, itemData) => {
  try {
    const itemRef = doc(db, "clothing", itemId);
    await updateDoc(itemRef, {
      ...itemData,
      updatedAt: serverTimestamp()
    });
    
    return { success: true };
  } catch (error) {
    console.error("Error al actualizar prenda:", error);
    return { success: false, error: error.message };
  }
};

// Eliminar prenda
export const deleteClothingItem = async (userId, itemId) => {
  try {
    // Verificar que la prenda pertenece al usuario
    const itemResult = await getClothingItem(itemId);
    if (!itemResult.success) {
      return itemResult;
    }
    
    if (itemResult.item.userId !== userId) {
      return { success: false, error: "No tienes permiso para eliminar esta prenda" };
    }
    
    await deleteDoc(doc(db, "clothing", itemId));
    return { success: true };
  } catch (error) {
    console.error("Error al eliminar prenda:", error);
    return { success: false, error: error.message };
  }
};
