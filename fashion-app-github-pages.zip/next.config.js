module.exports = {
  basePath: '',
  assetPrefix: '',
  images: {
    domains: ['via.placeholder.com', 'firebasestorage.googleapis.com'],
    loader: 'imgix',
    path: '',
  },
  trailingSlash: true,
  exportPathMap: async function () {
    return {
      '/': { page: '/' },
      '/locker': { page: '/locker' },
      '/outfits': { page: '/outfits' },
      '/inspiracion': { page: '/inspiracion' }
    }
  }
}
