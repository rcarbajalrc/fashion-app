import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { getInspirationFeed, getInspirationByCategory, likeInspirationPost, saveInspirationPost } from '../services/inspiration';
import BottomNav from '../components/BottomNav';
import Link from 'next/link';

export default function Inspiracion() {
  const { currentUser } = useAuth();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeFilter, setActiveFilter] = useState('destacados');

  useEffect(() => {
    const fetchPosts = async () => {
      if (currentUser) {
        setLoading(true);
        try {
          let result;
          
          if (activeFilter === 'destacados') {
            result = await getInspirationFeed(20);
          } else {
            result = await getInspirationByCategory(activeFilter, 20);
          }
          
          if (result.success) {
            setPosts(result.posts);
          } else {
            setError('Error al cargar el feed de inspiración');
          }
        } catch (error) {
          console.error("Error al cargar feed:", error);
          setError('Error al cargar el feed de inspiración');
        }
        setLoading(false);
      }
    };
    
    fetchPosts();
  }, [currentUser, activeFilter]);

  const handleLike = async (postId) => {
    if (!currentUser) return;
    
    try {
      const result = await likeInspirationPost(currentUser.uid, postId);
      if (result.success) {
        // Actualizar UI optimísticamente
        setPosts(posts.map(post => {
          if (post.id === postId) {
            return {
              ...post,
              likes: (post.likes || 0) + (result.action === 'liked' ? 1 : 0),
              isLiked: true
            };
          }
          return post;
        }));
      }
    } catch (error) {
      console.error("Error al dar like:", error);
    }
  };

  const handleSave = async (postId) => {
    if (!currentUser) return;
    
    try {
      const result = await saveInspirationPost(currentUser.uid, postId);
      if (result.success) {
        // Actualizar UI optimísticamente
        setPosts(posts.map(post => {
          if (post.id === postId) {
            return {
              ...post,
              isSaved: true
            };
          }
          return post;
        }));
      }
    } catch (error) {
      console.error("Error al guardar post:", error);
    }
  };

  // Datos de ejemplo para el feed de inspiración
  const samplePosts = [
    {
      id: '1',
      title: 'Estilo urbano minimalista',
      description: 'Combinación perfecta para un día casual en la ciudad. Prendas básicas con un toque moderno.',
      imageUrl: 'https://via.placeholder.com/600x800',
      categories: ['urbano', 'minimalista', 'otoño'],
      likes: 128,
      isLiked: false,
      isSaved: false
    },
    {
      id: '2',
      title: 'Elegancia casual para oficina',
      description: 'Un look profesional pero cómodo, perfecto para el entorno laboral moderno.',
      imageUrl: 'https://via.placeholder.com/600x800',
      categories: ['oficina', 'casual-formal', 'versátil'],
      likes: 95,
      isLiked: false,
      isSaved: false
    },
    {
      id: '3',
      title: 'Tendencias primavera 2025',
      description: 'Colores vibrantes y estampados que marcarán la temporada. Atrévete a destacar.',
      imageUrl: 'https://via.placeholder.com/600x800',
      categories: ['tendencia', 'primavera', 'colorido'],
      likes: 217,
      isLiked: false,
      isSaved: false
    }
  ];

  // Usar datos de ejemplo si no hay posts en Firebase
  const displayPosts = posts.length > 0 ? posts : samplePosts;

  return (
    <div className="pb-16">
      {/* Header */}
      <header className="bg-white p-4 flex justify-between items-center sticky top-0 z-10 shadow-sm">
        <h1 className="text-xl font-bold">Inspiración</h1>
        <div className="flex items-center">
          <button className="mr-4"><i className="fas fa-search text-gray-600"></i></button>
          <Link href="/perfil">
            <div className="w-8 h-8 bg-indigo-100 rounded-full overflow-hidden">
              <img src="https://via.placeholder.com/150" alt="Profile" className="w-full h-full object-cover" />
            </div>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-4">
        {/* Filters */}
        <div className="flex overflow-x-auto py-2 mb-4 no-scrollbar">
          <button 
            className={`px-4 py-2 ${activeFilter === 'destacados' ? 'bg-indigo-100 text-indigo-800' : 'bg-white border border-gray-200'} rounded-full mr-2 whitespace-nowrap`}
            onClick={() => setActiveFilter('destacados')}
          >
            Destacados
          </button>
          <button 
            className={`px-4 py-2 ${activeFilter === 'casual' ? 'bg-indigo-100 text-indigo-800' : 'bg-white border border-gray-200'} rounded-full mr-2 whitespace-nowrap`}
            onClick={() => setActiveFilter('casual')}
          >
            Casual
          </button>
          <button 
            className={`px-4 py-2 ${activeFilter === 'formal' ? 'bg-indigo-100 text-indigo-800' : 'bg-white border border-gray-200'} rounded-full mr-2 whitespace-nowrap`}
            onClick={() => setActiveFilter('formal')}
          >
            Formal
          </button>
          <button 
            className={`px-4 py-2 ${activeFilter === 'tendencias' ? 'bg-indigo-100 text-indigo-800' : 'bg-white border border-gray-200'} rounded-full mr-2 whitespace-nowrap`}
            onClick={() => setActiveFilter('tendencias')}
          >
            Tendencias
          </button>
          <button 
            className={`px-4 py-2 ${activeFilter === 'temporada' ? 'bg-indigo-100 text-indigo-800' : 'bg-white border border-gray-200'} rounded-full mr-2 whitespace-nowrap`}
            onClick={() => setActiveFilter('temporada')}
          >
            Temporada
          </button>
        </div>

        {/* Inspiration Feed */}
        {loading ? (
          <div className="flex justify-center items-center h-64">
            <p>Cargando inspiración...</p>
          </div>
        ) : error ? (
          <div className="text-center py-10">
            <p className="text-red-500">{error}</p>
          </div>
        ) : (
          <div className="inspiration-feed space-y-6">
            {displayPosts.map((post) => (
              <div key={post.id} className="inspiration-card bg-white rounded-xl overflow-hidden shadow-md">
                <div className="h-80 relative">
                  <img src={post.imageUrl} alt={post.title} className="w-full h-full object-cover" />
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold mb-2">{post.title}</h3>
                  <p className="text-gray-600 mb-3">{post.description}</p>
                  <div className="mb-3">
                    {post.categories && post.categories.map((category, index) => (
                      <span key={index} className="inline-block bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded-full mr-2 mb-2">
                        {category}
                      </span>
                    ))}
                  </div>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <button 
                        className={`${post.isLiked ? 'text-red-500' : 'text-gray-400 hover:text-red-500'}`}
                        onClick={() => handleLike(post.id)}
                      >
                        <i className={`${post.isLiked ? 'fas' : 'far'} fa-heart mr-1`}></i>
                        <span>{post.likes}</span>
                      </button>
                    </div>
                    <button 
                      className={`${post.isSaved ? 'text-indigo-600' : 'text-gray-400 hover:text-indigo-600'}`}
                      onClick={() => handleSave(post.id)}
                    >
                      <i className={`${post.isSaved ? 'fas' : 'far'} fa-bookmark`}></i>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Bottom Navigation */}
      <BottomNav active="inspiracion" />
    </div>
  );
}
