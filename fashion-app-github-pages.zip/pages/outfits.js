import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { getUserOutfits, getOutfitsByOccasion } from '../services/outfits';
import Link from 'next/link';
import BottomNav from '../components/BottomNav';

export default function Outfits() {
  const { currentUser } = useAuth();
  const [activeFilter, setActiveFilter] = useState('all');
  const [outfits, setOutfits] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const occasions = [
    { id: 'all', name: 'Todos' },
    { id: 'casual', name: 'Casual' },
    { id: 'formal', name: 'Formal' },
    { id: 'sport', name: 'Deportivo' },
    { id: 'party', name: 'Fiesta' },
    { id: 'work', name: 'Trabajo' }
  ];

  useEffect(() => {
    const fetchOutfits = async () => {
      if (currentUser) {
        setLoading(true);
        try {
          let result;
          
          if (activeFilter === 'all') {
            result = await getUserOutfits(currentUser.uid);
          } else {
            result = await getOutfitsByOccasion(currentUser.uid, activeFilter);
          }
          
          if (result.success) {
            setOutfits(result.outfits);
          } else {
            setError('Error al cargar los outfits');
          }
        } catch (error) {
          console.error("Error al cargar outfits:", error);
          setError('Error al cargar los outfits');
        }
        setLoading(false);
      }
    };
    
    fetchOutfits();
  }, [currentUser, activeFilter]);

  // Datos de ejemplo para mostrar cuando no hay outfits
  const sampleOutfits = [
    {
      id: '1',
      name: 'Casual de verano',
      occasion: 'casual',
      season: 'verano',
      imageUrl: 'https://via.placeholder.com/300?text=Outfit1',
      items: ['1', '2']
    },
    {
      id: '2',
      name: 'Formal para oficina',
      occasion: 'formal',
      season: 'todas',
      imageUrl: 'https://via.placeholder.com/300?text=Outfit2',
      items: ['2', '3']
    },
    {
      id: '3',
      name: 'Deportivo',
      occasion: 'sport',
      season: 'primavera',
      imageUrl: 'https://via.placeholder.com/300?text=Outfit3',
      items: ['3', '4']
    }
  ];

  // Usar datos de ejemplo si no hay outfits en Firebase
  const displayOutfits = outfits.length > 0 ? outfits : sampleOutfits;

  return (
    <div className="pb-16">
      {/* Header */}
      <header className="bg-white p-4 flex justify-between items-center sticky top-0 z-10 shadow-sm">
        <h1 className="text-xl font-bold">Mis Outfits</h1>
        <div className="flex items-center">
          <Link href="/crear-outfit">
            <button className="btn-primary">
              <i className="fas fa-plus mr-2"></i>Crear
            </button>
          </Link>
        </div>
      </header>

      {/* Filters */}
      <div className="bg-white p-4 shadow-sm">
        <div className="flex overflow-x-auto py-2 no-scrollbar">
          {occasions.map((occasion) => (
            <button
              key={occasion.id}
              className={`px-4 py-2 ${activeFilter === occasion.id ? 'bg-primary-100 text-primary-800' : 'bg-white border border-gray-200'} rounded-full mr-2 whitespace-nowrap`}
              onClick={() => setActiveFilter(occasion.id)}
            >
              {occasion.name}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <main className="p-4">
        {loading ? (
          <div className="flex justify-center items-center h-64">
            <p>Cargando outfits...</p>
          </div>
        ) : error ? (
          <div className="text-center py-10">
            <p className="text-red-500">{error}</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {displayOutfits.map((outfit) => (
              <Link href={`/outfit/${outfit.id}`} key={outfit.id}>
                <div className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow">
                  <div className="h-48 bg-gray-100 relative">
                    <img src={outfit.imageUrl} alt={outfit.name} className="w-full h-full object-cover" />
                    <span className="absolute top-2 right-2 bg-black bg-opacity-60 text-white px-2 py-1 rounded-full text-xs capitalize">
                      {outfit.occasion}
                    </span>
                  </div>
                  <div className="p-4">
                    <h3 className="font-medium">{outfit.name}</h3>
                    <div className="flex items-center text-gray-500 text-sm mt-1">
                      <i className="fas fa-tshirt mr-1"></i>
                      <span>{outfit.items ? outfit.items.length : 0} prendas</span>
                      <span className="mx-2">•</span>
                      <span className="capitalize">{outfit.season}</span>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}

        {!loading && !error && displayOutfits.length === 0 && (
          <div className="text-center py-10">
            <p className="text-gray-500">No tienes outfits en esta categoría</p>
            <Link href="/crear-outfit">
              <button className="mt-4 btn-primary">
                Crear outfit
              </button>
            </Link>
          </div>
        )}
      </main>

      {/* Bottom Navigation */}
      <BottomNav active="outfits" />
    </div>
  );
}
