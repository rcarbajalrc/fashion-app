import { useRouter } from 'next/router';
import { useState } from 'react';
import Link from 'next/link';
import { registerUser, loginUser } from '../services/firebase';
import { saveUserData } from '../services/user';

export default function Home() {
  const router = useRouter();
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [gender, setGender] = useState('');
  const [style, setStyle] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      if (isLogin) {
        // Iniciar sesión
        const result = await loginUser(email, password);
        if (result.success) {
          router.push('/locker');
        } else {
          setError(result.error || 'Error al iniciar sesión');
        }
      } else {
        // Registrar usuario
        const result = await registerUser(email, password);
        if (result.success) {
          // Guardar datos adicionales del usuario
          await saveUserData(result.user.uid, {
            displayName: name,
            gender,
            preferredStyle: style,
            email
          });
          router.push('/locker');
        } else {
          setError(result.error || 'Error al registrar usuario');
        }
      }
    } catch (error) {
      console.error("Error:", error);
      setError('Ocurrió un error inesperado');
    }

    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center">
      <div className="max-w-md w-full mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-primary-600">Fashion App</h1>
          <p className="text-gray-600 mt-2">Tu armario digital personal</p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-8">
          <div className="flex justify-center mb-6">
            <button
              className={`px-4 py-2 ${isLogin ? 'bg-primary-500 text-white' : 'bg-white text-gray-700'} rounded-l-lg font-medium`}
              onClick={() => setIsLogin(true)}
            >
              Iniciar Sesión
            </button>
            <button
              className={`px-4 py-2 ${!isLogin ? 'bg-primary-500 text-white' : 'bg-white text-gray-700'} rounded-r-lg font-medium`}
              onClick={() => setIsLogin(false)}
            >
              Registrarse
            </button>
          </div>

          {error && (
            <div className="bg-red-50 text-red-600 p-3 rounded-lg mb-4">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit}>
            {!isLogin && (
              <>
                <div className="mb-4">
                  <label className="block text-gray-700 text-sm font-medium mb-2" htmlFor="name">
                    Nombre
                  </label>
                  <input
                    id="name"
                    type="text"
                    className="input-field"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required={!isLogin}
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-gray-700 text-sm font-medium mb-2" htmlFor="gender">
                    Género
                  </label>
                  <select
                    id="gender"
                    className="input-field"
                    value={gender}
                    onChange={(e) => setGender(e.target.value)}
                    required={!isLogin}
                  >
                    <option value="">Seleccionar...</option>
                    <option value="male">Masculino</option>
                    <option value="female">Femenino</option>
                    <option value="other">Otro</option>
                  </select>
                </div>

                <div className="mb-4">
                  <label className="block text-gray-700 text-sm font-medium mb-2" htmlFor="style">
                    Estilo Preferido
                  </label>
                  <select
                    id="style"
                    className="input-field"
                    value={style}
                    onChange={(e) => setStyle(e.target.value)}
                    required={!isLogin}
                  >
                    <option value="">Seleccionar...</option>
                    <option value="casual">Casual</option>
                    <option value="formal">Formal</option>
                    <option value="sporty">Deportivo</option>
                    <option value="elegant">Elegante</option>
                    <option value="streetwear">Urbano</option>
                    <option value="minimalist">Minimalista</option>
                  </select>
                </div>
              </>
            )}

            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-medium mb-2" htmlFor="email">
                Correo Electrónico
              </label>
              <input
                id="email"
                type="email"
                className="input-field"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            <div className="mb-6">
              <label className="block text-gray-700 text-sm font-medium mb-2" htmlFor="password">
                Contraseña
              </label>
              <input
                id="password"
                type="password"
                className="input-field"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={6}
              />
            </div>

            <button
              type="submit"
              className="w-full btn-primary py-3"
              disabled={loading}
            >
              {loading ? 'Procesando...' : isLogin ? 'Iniciar Sesión' : 'Registrarse'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
