import { useEffect } from 'react';
import { useRouter } from 'next/router';
import { useAuth } from '../context/AuthContext';
import { AuthProvider } from '../context/AuthContext';
import '../styles/globals.css';

function MyApp({ Component, pageProps }) {
  return (
    <AuthProvider>
      <AppContent Component={Component} pageProps={pageProps} />
    </AuthProvider>
  );
}

function AppContent({ Component, pageProps }) {
  const { currentUser, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    // Proteger rutas que requieren autenticación
    const publicPaths = ['/', '/register'];
    const path = router.pathname;
    
    if (!loading) {
      if (!currentUser && !publicPaths.includes(path)) {
        // Redirigir a inicio de sesión si no está autenticado
        router.push('/');
      } else if (currentUser && path === '/') {
        // Redirigir al locker si ya está autenticado
        router.push('/locker');
      }
    }
  }, [currentUser, loading, router]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="mt-4 text-gray-600">Cargando...</p>
        </div>
      </div>
    );
  }

  return <Component {...pageProps} />;
}

export default MyApp;
