import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { getUserClothingItems, getClothingItemsByCategory } from '../services/wardrobe';
import Link from 'next/link';
import BottomNav from '../components/BottomNav';

export default function Locker() {
  const { currentUser } = useAuth();
  const [activeCategory, setActiveCategory] = useState('all');
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const categories = [
    { id: 'all', name: 'Todo' },
    { id: 'camisetas', name: 'Camisetas' },
    { id: 'pantalones', name: 'Pantalones' },
    { id: 'sudaderas', name: 'Sudaderas' },
    { id: 'gorras', name: 'Gorras' },
    { id: 'collares', name: 'Collares' },
    { id: 'relojes', name: 'Relojes' },
    { id: 'otros', name: 'Otros' }
  ];

  useEffect(() => {
    const fetchItems = async () => {
      if (currentUser) {
        setLoading(true);
        try {
          let result;
          
          if (activeCategory === 'all') {
            result = await getUserClothingItems(currentUser.uid);
          } else {
            result = await getClothingItemsByCategory(currentUser.uid, activeCategory);
          }
          
          if (result.success) {
            setItems(result.items);
          } else {
            setError('Error al cargar las prendas');
          }
        } catch (error) {
          console.error("Error al cargar prendas:", error);
          setError('Error al cargar las prendas');
        }
        setLoading(false);
      }
    };
    
    fetchItems();
  }, [currentUser, activeCategory]);

  // Datos de ejemplo para mostrar cuando no hay prendas
  const sampleItems = [
    {
      id: '1',
      name: 'Camiseta básica blanca',
      category: 'camisetas',
      color: 'blanco',
      season: 'todas',
      imageUrl: 'https://via.placeholder.com/150?text=Camiseta'
    },
    {
      id: '2',
      name: 'Pantalón vaquero azul',
      category: 'pantalones',
      color: 'azul',
      season: 'todas',
      imageUrl: 'https://via.placeholder.com/150?text=Pantalon'
    },
    {
      id: '3',
      name: 'Sudadera gris',
      category: 'sudaderas',
      color: 'gris',
      season: 'invierno',
      imageUrl: 'https://via.placeholder.com/150?text=Sudadera'
    },
    {
      id: '4',
      name: 'Gorra negra',
      category: 'gorras',
      color: 'negro',
      season: 'verano',
      imageUrl: 'https://via.placeholder.com/150?text=Gorra'
    }
  ];

  // Usar datos de ejemplo si no hay prendas en Firebase
  const displayItems = items.length > 0 ? items : sampleItems;

  return (
    <div className="pb-16">
      {/* Header */}
      <header className="bg-white p-4 flex justify-between items-center sticky top-0 z-10 shadow-sm">
        <h1 className="text-xl font-bold">Mi Armario</h1>
        <div className="flex items-center">
          <Link href="/anadir-prenda">
            <button className="btn-primary">
              <i className="fas fa-plus mr-2"></i>Añadir
            </button>
          </Link>
        </div>
      </header>

      {/* Categories */}
      <div className="bg-white p-4 shadow-sm">
        <div className="flex overflow-x-auto py-2 no-scrollbar">
          {categories.map((category) => (
            <button
              key={category.id}
              className={`px-4 py-2 ${activeCategory === category.id ? 'bg-primary-100 text-primary-800' : 'bg-white border border-gray-200'} rounded-full mr-2 whitespace-nowrap`}
              onClick={() => setActiveCategory(category.id)}
            >
              {category.name}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <main className="p-4">
        {loading ? (
          <div className="flex justify-center items-center h-64">
            <p>Cargando prendas...</p>
          </div>
        ) : error ? (
          <div className="text-center py-10">
            <p className="text-red-500">{error}</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {displayItems.map((item) => (
              <Link href={`/detalle-prenda/${item.id}`} key={item.id}>
                <div className="bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                  <div className="h-40 bg-gray-100">
                    <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="p-3">
                    <h3 className="font-medium text-sm truncate">{item.name}</h3>
                    <p className="text-xs text-gray-500 capitalize">{item.category}</p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}

        {!loading && !error && displayItems.length === 0 && (
          <div className="text-center py-10">
            <p className="text-gray-500">No tienes prendas en esta categoría</p>
            <Link href="/anadir-prenda">
              <button className="mt-4 btn-primary">
                Añadir prenda
              </button>
            </Link>
          </div>
        )}
      </main>

      {/* Bottom Navigation */}
      <BottomNav active="locker" />
    </div>
  );
}
