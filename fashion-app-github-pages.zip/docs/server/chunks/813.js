"use strict";
exports.id = 813;
exports.ids = [813];
exports.modules = {

/***/ 7749:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// Archivo de configuración de Firebase para la aplicación de moda
const firebaseConfig = {
    apiKey: "AIzaSyBmVAM_eiLrR7UmJwOFk2CxzlQQl-yCB2A",
    authDomain: "fashion-app-mvp-demo.firebaseapp.com",
    projectId: "fashion-app-mvp-demo",
    storageBucket: "fashion-app-mvp-demo.appspot.com",
    messagingSenderId: "123456789012",
    appId: "1:123456789012:web:abcdef1234567890abcdef",
    measurementId: "G-ABCDEF1234"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (firebaseConfig);


/***/ }),

/***/ 6813:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a$": () => (/* binding */ registerUser),
/* harmony export */   "db": () => (/* binding */ db),
/* harmony export */   "pH": () => (/* binding */ loginUser),
/* harmony export */   "yv": () => (/* binding */ onAuthStateChange)
/* harmony export */ });
/* unused harmony exports logoutUser, auth, storage */
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3745);
/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(401);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1492);
/* harmony import */ var firebase_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3392);
/* harmony import */ var _firebase_config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7749);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_auth__WEBPACK_IMPORTED_MODULE_1__, firebase_firestore__WEBPACK_IMPORTED_MODULE_2__, firebase_storage__WEBPACK_IMPORTED_MODULE_3__]);
([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_auth__WEBPACK_IMPORTED_MODULE_1__, firebase_firestore__WEBPACK_IMPORTED_MODULE_2__, firebase_storage__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// Servicio para la configuración y gestión de Firebase





// Inicializar Firebase
const app = (0,firebase_app__WEBPACK_IMPORTED_MODULE_0__.initializeApp)(_firebase_config__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z);
const auth = (0,firebase_auth__WEBPACK_IMPORTED_MODULE_1__.getAuth)(app);
const db = (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.getFirestore)(app);
const storage = (0,firebase_storage__WEBPACK_IMPORTED_MODULE_3__.getStorage)(app);
// Función para registrar un nuevo usuario
const registerUser = async (email, password)=>{
    try {
        const userCredential = await (0,firebase_auth__WEBPACK_IMPORTED_MODULE_1__.createUserWithEmailAndPassword)(auth, email, password);
        return {
            success: true,
            user: userCredential.user
        };
    } catch (error) {
        console.error("Error al registrar usuario:", error);
        return {
            success: false,
            error: error.message
        };
    }
};
// Función para iniciar sesión
const loginUser = async (email, password)=>{
    try {
        const userCredential = await (0,firebase_auth__WEBPACK_IMPORTED_MODULE_1__.signInWithEmailAndPassword)(auth, email, password);
        return {
            success: true,
            user: userCredential.user
        };
    } catch (error) {
        console.error("Error al iniciar sesi\xf3n:", error);
        return {
            success: false,
            error: error.message
        };
    }
};
// Función para cerrar sesión
const logoutUser = async ()=>{
    try {
        await signOut(auth);
        return {
            success: true
        };
    } catch (error) {
        console.error("Error al cerrar sesi\xf3n:", error);
        return {
            success: false,
            error: error.message
        };
    }
};
// Exportar instancias de Firebase

// Exportar función para observar cambios en el estado de autenticación
const onAuthStateChange = (callback)=>{
    return (0,firebase_auth__WEBPACK_IMPORTED_MODULE_1__.onAuthStateChanged)(auth, callback);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;