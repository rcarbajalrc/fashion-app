# Fashion App - Tu armario digital personal

Esta aplicación web progresiva (PWA) te permite organizar tu ropa y crear outfits digitalmente.

## Características

- Armario digital para guardar y categorizar tus prendas
- Creación de outfits combinando prendas
- Feed de inspiración con tendencias de moda
- Diseño responsive para cualquier dispositivo

## Tecnologías utilizadas

- React.js
- Next.js
- Firebase (autenticación, base de datos, almacenamiento)
- Tailwind CSS
