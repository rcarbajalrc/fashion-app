import Link from 'next/link';

export default function BottomNav({ active }) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center h-16 z-20">
      <Link href="/locker">
        <div className={`flex flex-col items-center ${active === 'locker' ? 'text-primary-600' : 'text-gray-500'}`}>
          <i className="fas fa-tshirt text-lg"></i>
          <span className="text-xs mt-1">Armario</span>
        </div>
      </Link>
      
      <Link href="/outfits">
        <div className={`flex flex-col items-center ${active === 'outfits' ? 'text-primary-600' : 'text-gray-500'}`}>
          <i className="fas fa-user-tie text-lg"></i>
          <span className="text-xs mt-1">Outfits</span>
        </div>
      </Link>
      
      <Link href="/inspiracion">
        <div className={`flex flex-col items-center ${active === 'inspiracion' ? 'text-primary-600' : 'text-gray-500'}`}>
          <i className="fas fa-lightbulb text-lg"></i>
          <span className="text-xs mt-1">Inspiración</span>
        </div>
      </Link>
      
      <Link href="/perfil">
        <div className={`flex flex-col items-center ${active === 'perfil' ? 'text-primary-600' : 'text-gray-500'}`}>
          <i className="fas fa-user text-lg"></i>
          <span className="text-xs mt-1">Perfil</span>
        </div>
      </Link>
    </nav>
  );
}
